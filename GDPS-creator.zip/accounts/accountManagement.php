<?php
header("Location: ../tools");
?>