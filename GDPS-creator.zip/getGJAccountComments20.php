<?php
include "incl/comments/getGJAccountComments.php";
?>