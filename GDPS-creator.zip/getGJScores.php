<?php
include "incl/scores/getGJScores.php";
?>